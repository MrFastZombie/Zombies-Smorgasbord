----------------[Terms of use]---------------------

You can:
✅-Use it as a placeholder
✅-Use it as a reference or base for your own content
✅-Use it on a server or in mod packs
✅-Alter it for personal use
✅-Use and edit it for YouTube videos and Content Creator edits

You cannot:
❌-Claim ownership over anything made or used by this pack
❌-Redistribute edited or unedited assets as is
❌-Re-upload the pack

By doing any allowed of the above, you agree to follow these requirements:

- Give clear credits depending on the media (e.g., Video Descriptions, Page Descriptions)
- Link back to any of the pages of this pack (Planetminecraft, CurseForge, Modrinth)
- Don't take credit for anything you didn't make and be honest about what you used
- Include our credits file, which may be used as template if there is none, or include us in your credits file if available
- Ask for usage when it comes to resource packs

We reserve the right to:

- Refuse the usage of our pack in any way
- Change these usage guidelines at any time for any reason

If you use anything out of this pack that includes the NegativeSpaces4 resource pack under Creative Commons Attribution 4.0 International terms, you need to credit AmberW/AmberWat.

----------------[Credit]---------------------------


--Pack Creators:--

mr_ch0c0late (Creator and Idea)

Curse Forge: 		https://www.curseforge.com/members/mr_ch0c0late1
Planet Minecraft: 	https://www.planetminecraft.com/member/mr_ch0c0late1/
Twitter: 			https://twitter.com/mr_ch0c0late1



Zartrix 

Curse Forge:		https://www.curseforge.com/members/zartrix
Reddit: 			https://www.reddit.com/user/Zartrix



AmberW/AmberWat

GitHub:			https://github.com/AmberWat
Discord(Minecraft Commands)